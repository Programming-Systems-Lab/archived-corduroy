public class CloneableObject implements Cloneable {

    public Object clone() { return this; }

}
