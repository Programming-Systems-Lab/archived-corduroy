public class Corduroy
{
    public static boolean inTest = false;
}